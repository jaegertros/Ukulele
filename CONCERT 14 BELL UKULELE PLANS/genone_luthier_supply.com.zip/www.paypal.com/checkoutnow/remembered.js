window.shopifypaypalisrememberedcallback({
    "paypal": true,
    "venmo": false
});